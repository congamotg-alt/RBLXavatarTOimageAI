import requests, subprocess, sys
import win32clipboard
import win32con
import io
import os

from PIL import Image

# get username from robloxUSR.txt
with open("robloxUSR.txt", "r") as f:
    username = f.read().strip()

def copy_image_to_clipboard(path):
    image = Image.open(path)

    output = io.BytesIO()
    image.convert("RGB").save(output, "BMP")
    data = output.getvalue()[14:]  # remove BMP header
    output.close()

    win32clipboard.OpenClipboard()
    win32clipboard.EmptyClipboard()
    win32clipboard.SetClipboardData(win32con.CF_DIB, data)
    win32clipboard.CloseClipboard()

# username to user id
url = "https://users.roblox.com/v1/usernames/users"
body = {
  "usernames": [username],
  "excludeBannedUsers": False
}
response = requests.post(url, json=body)
ID = response.json().get("data")[0].get("id")

# user ID to avatar image
avatar_url = f"https://thumbnails.roblox.com/v1/users/avatar?userIds={ID}&size=720x720&format=Png&isCircular=false"
avatar_values = requests.get(avatar_url)
imageURL = avatar_values.json().get("data")[0].get("imageUrl")
image = requests.get(imageURL)
with open("avatar.png", "wb") as f:
    f.write(image.content)

def find_edge_path():
    possible_paths = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe")
    ]

    for path in possible_paths:
        if os.path.isfile(path):
            return path

    return None

edge_path = find_edge_path()

aiLINK = requests.get("https://raw.githubusercontent.com/congamotg-alt/RBLXavatarTOimageAI/refs/heads/main/LINK.txt").text.strip()

if edge_path:
    subprocess.Popen([edge_path, f'--app={aiLINK}'])
else:
    print("Microsoft Edge not found on this system.")

#copies the image to clipboard
copy_image_to_clipboard("avatar.png")
