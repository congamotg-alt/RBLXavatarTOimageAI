import requests, win32clipboard, win32con, os

# get username from robloxUSR.txt
with open("robloxUSR.txt", "r") as f:
  username = f.read().strip()

# username to user id
url = "https://users.roblox.com/v1/usernames/users"
body = {
  "usernames": [username],
  "excludeBannedUsers": False
}
response = requests.post(url, json=body)

def append_to_desc(key, choice):
  desc.append(f"{key}: {' '.join(choice.split(' ')[1:])}\n")
  
# user ID to display name and copy
desc = []
while True:
  os.system("cls")
  print ("1. Signature (any args for handwritten)")
  print ("2. Add tags")
  print ("3. Setting")
  print ("4. Style (Anime by default)")
  print ("5. (OPTIONAL) Description")
  print ("6. Finalize")
  choice = input('"1-6 args": ')
  if choice.split(" ")[0] == "1":
    try:
      if choice.split(" ")[1]:
        desc.append(f"Signature (Handwritten): {response.json().get('data')[0].get('displayName')}\n")
    except IndexError:
      desc.append(f"Signature: {response.json().get('data')[0].get('displayName')}\n")
  elif choice.split(" ")[0] == "2":
    append_to_desc("Tags", choice)
  elif choice.split(" ")[0] == "3":
    append_to_desc("Setting", choice)
  elif choice.split(" ")[0] == "4":
    append_to_desc("Style", choice)
  elif choice.split(" ")[0] == "5":
    append_to_desc("Description", choice)
  elif choice.split(" ")[0] == "6":
    break

win32clipboard.OpenClipboard()
win32clipboard.EmptyClipboard()
win32clipboard.SetClipboardData(win32con.CF_UNICODETEXT, " ".join(desc))
win32clipboard.CloseClipboard()